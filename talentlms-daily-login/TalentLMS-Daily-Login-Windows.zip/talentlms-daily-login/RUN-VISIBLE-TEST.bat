@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo First run START-HERE.bat to install the required components.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" talentlms_login.py --visible
pause
