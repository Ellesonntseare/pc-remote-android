$ErrorActionPreference = 'Stop'
$projectDir = $PSScriptRoot
$python = Join-Path $projectDir '.venv\Scripts\pythonw.exe'
$script = Join-Path $projectDir 'talentlms_login.py'
if (-not (Test-Path $python)) { throw 'Python environment missing. Run START-HERE.bat first.' }

$time = Read-Host 'What time every day? Use HH:mm (24-hour clock). Press Enter for 08:00'
if ([string]::IsNullOrWhiteSpace($time)) { $time = '08:00' }
try { $parsed = [datetime]::ParseExact($time, 'HH:mm', [System.Globalization.CultureInfo]::InvariantCulture) }
catch { throw 'Invalid time. Please use 24-hour HH:mm, for example 08:00 or 19:30.' }

$at = (Get-Date).Date.Add($parsed.TimeOfDay)
$action = New-ScheduledTaskAction -Execute $python -Argument ('"{0}"' -f $script) -WorkingDirectory $projectDir
$trigger = New-ScheduledTaskTrigger -Daily -At $at
$currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$principal = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName 'TalentLMS Daily Login' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
Write-Host "Daily task created for $time (your Windows local time)."
Write-Host 'Your PC must be awake and you must be signed into Windows for this task to run.'
Write-Host 'If the scheduled time is missed while the PC is asleep, Task Scheduler will try when available.'
Write-Host "Logs: $env:LOCALAPPDATA\TalentLMSDailyLogin\activity.log"
