@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Unregister-ScheduledTask -TaskName 'TalentLMS Daily Login' -Confirm:$false -ErrorAction SilentlyContinue"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" talentlms_login.py --clear
)
echo Daily schedule removed; saved credentials and browser session cleared if Python was available.
pause
