"""Daily TalentLMS sign-in for Windows.

Credentials live in Windows Credential Manager via keyring, not in this file.
"""

from __future__ import annotations

import argparse
import getpass
import logging
import os
import re
import shutil
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

TARGET_URL = "https://intersect-alfharon.talentlms.com/plus/my/training"
LOGIN_URL = "https://intersect-alfharon.talentlms.com/plus/login?redirect=%2Fmy%2Ftraining"
HOST = "intersect-alfharon.talentlms.com"
SERVICE = "TalentLMS Daily Login - intersect-alfharon"
DATA_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "TalentLMSDailyLogin"
BROWSER_DIR = DATA_DIR / "browser-profile"
LOG_FILE = DATA_DIR / "activity.log"


def configure_logging() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8"), logging.StreamHandler(sys.stdout)],
    )


def setup_credentials() -> None:
    import keyring

    print(f"Credentials for {HOST} will be saved to Windows Credential Manager.")
    username = input("TalentLMS username or email: ").strip()
    if not username:
        raise ValueError("Username cannot be empty.")
    password = getpass.getpass("TalentLMS password (hidden): ")
    if not password:
        raise ValueError("Password cannot be empty.")
    keyring.set_password(SERVICE, "username", username)
    keyring.set_password(SERVICE, "password", password)
    print("Credentials saved. The password is not written to the script or log.")


def read_credentials() -> tuple[str, str]:
    import keyring

    username = keyring.get_password(SERVICE, "username")
    password = keyring.get_password(SERVICE, "password")
    if not username or not password:
        raise RuntimeError("No saved login found. Run SET-LOGIN.bat first.")
    return username, password


def at_training_page(url: str) -> bool:
    parsed = urlparse(url)
    return (
        parsed.scheme == "https"
        and parsed.hostname == HOST
        and parsed.path.rstrip("/").startswith("/plus/my/training")
    )


def visible_password_field(page) -> bool:
    try:
        for element in page.locator('input[type="password"]').all():
            if element.is_visible():
                return True
    except Exception:
        pass
    return False


def training_is_ready(page) -> bool:
    if not at_training_page(page.url) or visible_password_field(page):
        return False
    # TalentLMS is a JS app. Wait until the root UI has rendered, not just the URL.
    try:
        text = page.locator("body").inner_text(timeout=3000).lower()
        return bool(text.strip()) and not ("you need to enable javascript" in text)
    except Exception:
        return False


def wait_for_training(page, seconds: int) -> bool:
    deadline = time.monotonic() + seconds
    matched_at = None
    while time.monotonic() < deadline:
        if training_is_ready(page):
            if matched_at is None:
                matched_at = time.monotonic()
            elif time.monotonic() - matched_at >= 1.5:
                return True
        else:
            matched_at = None
        time.sleep(0.6)
    return False


def first_visible(locator):
    """Return first matching visible Playwright locator or None."""
    try:
        count = min(locator.count(), 15)
        for index in range(count):
            item = locator.nth(index)
            if item.is_visible() and item.is_enabled():
                return item
    except Exception:
        pass
    return None


def find_username(page):
    selectors = (
        'input[autocomplete="username"]',
        'input[type="email"]',
        'input[name="username" i]',
        'input[name="email" i]',
        'input[id*="user" i]',
        'input[placeholder*="email" i]',
        'input[placeholder*="user" i]',
        'input[type="text"]',
    )
    for selector in selectors:
        element = first_visible(page.locator(selector))
        if element:
            return element
    for pattern in (r"username|email", r"user name"):
        element = first_visible(page.get_by_role("textbox", name=re.compile(pattern, re.I)))
        if element:
            return element
    return None


def submit_login(page, password_element) -> None:
    candidates = [
        page.get_by_role("button", name=re.compile(r"^(log\s?in|login|sign\s?in)$", re.I)),
        page.locator('button[type="submit"]'),
        page.locator('input[type="submit"]'),
        page.locator('button:has-text("Login")'),
        page.locator('button:has-text("Log in")'),
        page.locator('button:has-text("Sign in")'),
    ]
    for candidate in candidates:
        button = first_visible(candidate)
        if button:
            button.click(timeout=10000)
            return
    password_element.press("Enter")


def perform_login(show_browser: bool) -> bool:
    from playwright.sync_api import sync_playwright

    username, password = read_credentials()
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    # This dedicated browser profile may contain login cookies. Keep it private.
    with sync_playwright() as playwright:
        context = playwright.chromium.launch_persistent_context(
            user_data_dir=str(BROWSER_DIR),
            headless=not show_browser,
            viewport={"width": 1280, "height": 850},
            accept_downloads=False,
        )
        try:
            context.set_default_timeout(12000)
            page = context.pages[0] if context.pages else context.new_page()
            logging.info("Opening training page: %s", TARGET_URL)
            page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=60000)
            if wait_for_training(page, seconds=5):
                logging.info("SUCCESS: Training page loaded using a saved session.")
                return True

            # If not redirected automatically, open the site's login page.
            if not visible_password_field(page):
                page.goto(LOGIN_URL, wait_until="domcontentloaded", timeout=60000)
                for _ in range(15):
                    if visible_password_field(page) or training_is_ready(page):
                        break
                    time.sleep(0.5)

            if wait_for_training(page, seconds=2):
                logging.info("SUCCESS: Already signed in.")
                return True

            pwd = first_visible(page.locator('input[type="password"]'))
            user = find_username(page)
            if not pwd or not user:
                raise RuntimeError(
                    "Could not locate a normal username/password form. "
                    "The portal may require single sign-on or a changed login page."
                )

            logging.info("Login form detected; signing in.")
            user.fill(username)
            pwd.fill(password)
            submit_login(page, pwd)
            max_wait = 120 if show_browser else 30
            deadline = time.monotonic() + max_wait
            while time.monotonic() < deadline:
                if wait_for_training(page, seconds=2):
                    logging.info("SUCCESS: Signed in and reached My Training.")
                    return True
                current_path = urlparse(page.url).path
                # The portal may land on a dashboard first; navigate to training.
                if current_path.startswith("/plus/my/") and not at_training_page(page.url):
                    page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=45000)
                    continue
                if not show_browser:
                    content = page.locator("body").inner_text(timeout=3000).lower()
                    if any(term in content for term in (
                        "verification code", "two-factor authentication", "authenticator",
                        "captcha", "check your inbox", "security code"
                    )):
                        raise RuntimeError(
                            "Login needs a one-time verification or CAPTCHA. "
                            "Run RUN-VISIBLE-TEST.bat to complete it manually."
                        )
                time.sleep(0.5)
            raise RuntimeError(
                "Login wasn't confirmed. Check your credentials, any verification prompt, "
                "or whether the site's login screen has changed."
            )
        finally:
            context.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Daily TalentLMS login helper")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--setup", action="store_true", help="Securely save or update your login")
    group.add_argument("--clear", action="store_true", help="Remove saved credentials and browser session")
    group.add_argument("--visible", action="store_true", help="Run login with a visible browser for testing or 2FA")
    args = parser.parse_args()
    configure_logging()

    try:
        if args.setup:
            setup_credentials()
        elif args.clear:
            import keyring
            for key in ("username", "password"):
                try:
                    keyring.delete_password(SERVICE, key)
                except keyring.errors.PasswordDeleteError:
                    pass
            if BROWSER_DIR.exists():
                shutil.rmtree(BROWSER_DIR)
            print("Saved credentials and the dedicated browser session were cleared.")
        else:
            if not perform_login(show_browser=args.visible):
                return 1
        return 0
    except KeyboardInterrupt:
        logging.error("Interrupted by user.")
        return 130
    except Exception as exc:
        # Avoid logging passwords, usernames, URLs with credentials or page content.
        logging.error("FAILED: %s", str(exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
