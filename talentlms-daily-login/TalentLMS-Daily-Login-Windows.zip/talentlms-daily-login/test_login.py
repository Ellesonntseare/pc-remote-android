import unittest
from talentlms_login import at_training_page


class URLChecks(unittest.TestCase):
    def test_exact_training_url(self):
        self.assertTrue(at_training_page('https://intersect-alfharon.talentlms.com/plus/my/training'))

    def test_subroute(self):
        self.assertTrue(at_training_page('https://intersect-alfharon.talentlms.com/plus/my/training/3987'))

    def test_login_not_success(self):
        self.assertFalse(at_training_page('https://intersect-alfharon.talentlms.com/plus/login'))

    def test_unrelated_domain_not_success(self):
        self.assertFalse(at_training_page('https://elsewhere.com/plus/my/training'))


if __name__ == '__main__':
    unittest.main()
