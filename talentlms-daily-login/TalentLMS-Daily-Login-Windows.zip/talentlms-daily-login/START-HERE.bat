@echo off
setlocal
cd /d "%~dp0"
title TalentLMS Daily Login - Setup

echo ===================================================
echo  TalentLMS Daily Login - Windows setup
 echo ===================================================
echo.
where py >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install Python 3 from https://www.python.org/downloads/windows/
  echo Then run this file again. Enable the Python launcher if prompted.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating Python environment...
  py -3 -m venv .venv
  if errorlevel 1 goto :failed
)

echo Installing browser automation and secure credential storage...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :failed

echo Installing Chromium browser for the automation...
".venv\Scripts\python.exe" -m playwright install chromium
if errorlevel 1 goto :failed

echo.
echo Step 1: Save your own account details securely.
".venv\Scripts\python.exe" talentlms_login.py --setup
if errorlevel 1 goto :failed

echo.
echo Step 2: Test login in a visible browser.
echo If verification is required, complete it in the browser.
".venv\Scripts\python.exe" talentlms_login.py --visible
if errorlevel 1 (
  echo The login test did not succeed. Try RUN-VISIBLE-TEST.bat after fixing the issue.
  echo No daily task has been created yet.
  pause
  exit /b 1
)

echo.
echo Step 3: Choose the daily time.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0SCHEDULE-DAILY.ps1"
if errorlevel 1 goto :failed

echo.
echo Setup complete. View results in your activity log.
pause
exit /b 0

:failed
echo Setup failed. Please read the message above.
pause
exit /b 1
